
public class DataStore {
	
	public static Furniture[] furnitures = {
			new Furniture("Home", "Chair", FurnitureColors.SANDALWOOD, 244, 164, 96, OtherColors.LIGHT_BLUE, 173, 216, 230, 6, 2300.00),
			new Furniture("Home", "Chair", FurnitureColors.SANDALWOOD, 244, 164, 96, OtherColors.LIGHT_BLUE, 173, 216, 230, 6, 2300.00),
			new Furniture("Home", "Table", FurnitureColors.RED_BROWN, 165, 42, 42, OtherColors.LIGHT_BLUE, 173, 216, 230, 6, 2340.00),
			new Furniture("Home", "Chair", FurnitureColors.SANDALWOOD,244, 164, 96, OtherColors.LIGHT_BLUE,173, 216, 230, 6, 1300.00),
			new Furniture("Home", "Table", FurnitureColors.SANDALWOOD, 244, 164, 96,OtherColors.LIGHT_PURPULE, 173, 216, 191, 216, 2000.00),
			new Furniture("Home", "Chair", FurnitureColors.SANDALWOOD, 244, 164, 96, OtherColors.LIGHT_PURPULE,173, 216, 230, 6, 1000.00),
			new Furniture("Home", "Table", FurnitureColors.SANDALWOOD, 244, 164, 96, OtherColors.LIGHT_PURPULE, 173, 216, 230, 6, 2300.00),
			new Furniture("Home", "Chair", FurnitureColors.BROWN, 139, 69, 19, OtherColors.LIGHT_PURPULE, 173, 216, 230, 8, 1500.00)
	};

	public DataStore() {
		// TODO Auto-generated constructor stub
	}

}
