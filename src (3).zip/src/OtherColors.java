
public enum OtherColors {
	GREEN,
	WHITE,
	LIGHT_BLUE,
	LIGHT_PURPULE,
	YELLOW
}
