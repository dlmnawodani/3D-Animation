
public enum FurnitureColors {
	 MAHOGANY,
     TEAK,
     SANDALWOOD,
     RED_BROWN,
     BROWN
}
